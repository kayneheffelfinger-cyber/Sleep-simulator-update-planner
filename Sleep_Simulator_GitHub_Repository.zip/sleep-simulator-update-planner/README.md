# Sleep Simulator — Update Planner

A polished Excel workbook for planning, tracking, and testing updates to a Roblox game called **Sleep Simulator**.

The workbook is designed around the game's existing systems:

- Different types of beds
- Rebirth progression
- Skill tree
- Robux shop selling the premium currency **Zzz**

It helps organize feature ideas, prioritize development, prepare prompts for Claude and Codex, track Claude Free usage sessions, test releases in Roblox Studio, and review progression/economy values.

## Workbook

Open [`Sleep_Simulator_Update_Planner.xlsx`](Sleep_Simulator_Update_Planner.xlsx) in Microsoft Excel or a compatible spreadsheet application.

### Worksheets

| Worksheet | What it is for |
|---|---|
| Start Here | Dashboard, current systems, workflow, and project safety rules |
| Roadmap | Ten staged update themes and their completion criteria |
| Backlog | Individual feature and bug tasks with priority/status tracking |
| Prompt Library | Copy-ready prompts for Claude and Codex |
| Claude Sessions | Plan work across Claude's usage windows and record handoffs |
| Test Checklist | Roblox Studio regression and release tests |
| Economy Audit | Record actual bed, rebirth, skill, and Zzz economy values |

## Suggested workflow

1. Use Claude to develop a feature idea into a clear specification and acceptance criteria.
2. Use Codex to inspect and implement one bounded task in the actual project repository.
3. Review the changed files and ask for a code/security review.
4. Test the feature in Roblox Studio, including returning-player and multiplayer scenarios where relevant.
5. Record the result in the backlog and test checklist before starting the next update.

## Important project safeguards

- Treat the beds, rebirths, skill tree, player saving, and Zzz purchase flow as existing systems. Do not rebuild them without a specific reason and an approved plan.
- Back up or commit the Roblox project before each meaningful change.
- Do not casually rename saved-data keys or reset player data. Require a compatibility/migration plan for schema changes.
- Keep Robux purchase validation and premium-currency grants server-authoritative.
- Never place API keys, passwords, or private credentials in prompts or source control.
- Have only one AI edit the same project files at a time.

## Previews

### Dashboard

![Dashboard preview](assets/dashboard-preview.png)

### Roadmap

![Roadmap preview](assets/roadmap-preview.png)

### Prompt library

![Prompt library preview](assets/prompt-library-preview.png)

### Test checklist

![Test checklist preview](assets/test-checklist-preview.png)

## Repository details

- **Suggested repository name:** `sleep-simulator-update-planner`
- **Suggested description:** `A polished development roadmap, AI prompt library, and testing tracker for the Roblox game Sleep Simulator.`
- **Suggested visibility:** Private is a good default if you do not want the planning workbook and development notes to be public.

This repository contains the planner workbook and its previews. It does **not** contain the Roblox game's source code.
